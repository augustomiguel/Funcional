# Ativ2

Projeto para a Atividade 2 da disciplina Programação 
Funcional, semestre 2023.2. 

Edite o arquivo `ativ2.ex` no diretório `lib` de 
acordo com as instruções. Para verificar a solução, 
execute os testes usando

```
mix test
```

Os testes estão no arquivo `ativ2_test.exs` no diretório `test`.
