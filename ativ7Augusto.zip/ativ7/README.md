# Atividade 7

Projeto para Atividade 7 da disciplina "Programacao Funcional": 
Recursividade de cauda e acumuladores. 
